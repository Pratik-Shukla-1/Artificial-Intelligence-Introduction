## HW1 repo for Fall 2021 UMBC CMSC 671

Enter your full name and UMBC username and any comments you want to add to this README.md document

Replace the empty files oped.pdf and tweet.txt with your your versions and commit them and README.md and push the results back to GitHub

**full name:**  Pratik Ketanbhai Shukla 

**umbc username:**  pratiks2

**comments:**
